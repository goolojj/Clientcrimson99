# CrimsonGold Client (Fabric 1.21.11)

Fast, lightweight PvP Client mod built for **Minecraft 1.21.11 (Fabric)** with a **Crimson & Gold** ClickGUI (`Right Shift`).

## Features Included
- **Hitbox** toggle (entity hitboxes without F3+B)
- **FPS Boost** (disables heavy entity shadows & optimizes HUD)
- **Outline** (clean entity target outlines within 32 blocks)
- **Motion Blur** (smooth camera-turn motion blur)
- **ToggleSprint**, **Zoom (`C`)**, **NoHurtCam**, **Fullbright**
- **PvP HUD**: FPS, XYZ Coords, CPS Counter, Keystrokes (`WASD + LMB/RMB`), Armor HUD

## Build `.jar` on Mobile (Zero PC Needed via GitHub Actions)
1. Create a new repository on GitHub (mobile browser).
2. Upload all files from this ZIP (including the `.github` folder!).
3. Open the **Actions** tab on GitHub and wait ~2 minutes for **Build CrimsonGold Client (1.21.11)** to finish.
4. Download the `CrimsonGold-Client-1.21.11` artifact `.jar` and put it in your `mods/` folder with **Fabric API 1.21.11**!
