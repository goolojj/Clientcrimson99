package com.crimsongold;

import com.crimsongold.config.ClientConfig;
import com.crimsongold.gui.CrimsonClickGui;
import com.crimsongold.hud.CrimsonHudRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class CrimsonGoldClient implements ClientModInitializer {
    public static ClientConfig CONFIG;
    public static KeyBinding MENU_KEY;
    public static KeyBinding ZOOM_KEY;
    public static boolean isZooming = false;

    private static final Deque<Long> LEFT_CLICKS = new ArrayDeque<>();
    private static final Deque<Long> RIGHT_CLICKS = new ArrayDeque<>();
    private static boolean prevLeftDown = false;
    private static boolean prevRightDown = false;

    @Override
    public void onInitializeClient() {
        CONFIG = ClientConfig.load();

        MENU_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.crimsongold.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.crimsongold"
        ));

        ZOOM_KEY = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.crimsongold.zoom",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_C,
                "category.crimsongold"
        ));

        HudRenderCallback.EVENT.register(new CrimsonHudRenderer());

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            while (MENU_KEY.wasPressed()) {
                client.setScreen(new CrimsonClickGui());
            }

            isZooming = ZOOM_KEY.isPressed();

            // ToggleSprint
            if (CONFIG.toggleSprintEnabled && client.options.forwardKey.isPressed() && !client.player.isSneaking()) {
                client.player.setSprinting(true);
            }

            // Hitbox toggle sync
            if (client.getEntityRenderDispatcher() != null) {
                client.getEntityRenderDispatcher().setRenderHitboxes(CONFIG.hitboxEnabled);
            }

            // FPS Boost lightweight tweaks
            if (CONFIG.fpsBoostEnabled) {
                client.options.getEntityShadows().setValue(false);
            }

            // Track CPS
            long now = System.currentTimeMillis();
            boolean leftDown = client.options.attackKey.isPressed();
            boolean rightDown = client.options.useKey.isPressed();
            if (leftDown && !prevLeftDown) LEFT_CLICKS.addLast(now);
            if (rightDown && !prevRightDown) RIGHT_CLICKS.addLast(now);
            prevLeftDown = leftDown;
            prevRightDown = rightDown;

            while (!LEFT_CLICKS.isEmpty() && now - LEFT_CLICKS.peekFirst() > 1000L) LEFT_CLICKS.removeFirst();
            while (!RIGHT_CLICKS.isEmpty() && now - RIGHT_CLICKS.peekFirst() > 1000L) RIGHT_CLICKS.removeFirst();
        });
    }

    public static int getLeftCps() {
        return LEFT_CLICKS.size();
    }

    public static int getRightCps() {
        return RIGHT_CLICKS.size();
    }
}
