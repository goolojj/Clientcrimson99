package com.crimsongold.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class ClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("crimsongold-client.json");

    // Requested Core Modules
    public boolean hitboxEnabled = false;
    public boolean fpsBoostEnabled = true;
    public boolean outlineEnabled = true;
    public boolean motionBlurEnabled = false;
    public float motionBlurStrength = 0.35f;

    // Bonus PvP & HUD Modules
    public boolean toggleSprintEnabled = true;
    public boolean fullbrightEnabled = true;
    public boolean noHurtCamEnabled = true;
    public boolean hudEnabled = true;
    public boolean keystrokesEnabled = true;
    public boolean armorHudEnabled = true;
    public boolean cpsCounterEnabled = true;

    public static ClientConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                return GSON.fromJson(Files.readString(CONFIG_PATH), ClientConfig.class);
            } catch (Exception ignored) {
            }
        }
        ClientConfig cfg = new ClientConfig();
        cfg.save();
        return cfg;
    }

    public void save() {
        try {
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }
}
