package com.crimsongold.gui;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class CrimsonClickGui extends Screen {
    public CrimsonClickGui() {
        super(Text.literal("CrimsonGold Client"));
    }

    @Override
    protected void init() {
        ClientConfig cfg = CrimsonGoldClient.CONFIG;
        int colW = 150;
        int btnH = 22;
        int gap = 6;
        int startX1 = this.width / 2 - colW - 8;
        int startX2 = this.width / 2 + 8;
        int y = this.height / 2 - 80;

        addToggle(startX1, y, colW, btnH, "Hitbox", cfg.hitboxEnabled, v -> cfg.hitboxEnabled = v);
        addToggle(startX2, y, colW, btnH, "FPS Boost", cfg.fpsBoostEnabled, v -> cfg.fpsBoostEnabled = v);
        y += btnH + gap;

        addToggle(startX1, y, colW, btnH, "Outline", cfg.outlineEnabled, v -> cfg.outlineEnabled = v);
        addToggle(startX2, y, colW, btnH, "Motion Blur", cfg.motionBlurEnabled, v -> cfg.motionBlurEnabled = v);
        y += btnH + gap;

        addToggle(startX1, y, colW, btnH, "ToggleSprint", cfg.toggleSprintEnabled, v -> cfg.toggleSprintEnabled = v);
        addToggle(startX2, y, colW, btnH, "Fullbright", cfg.fullbrightEnabled, v -> cfg.fullbrightEnabled = v);
        y += btnH + gap;

        addToggle(startX1, y, colW, btnH, "NoHurtCam", cfg.noHurtCamEnabled, v -> cfg.noHurtCamEnabled = v);
        addToggle(startX2, y, colW, btnH, "Keystrokes", cfg.keystrokesEnabled, v -> cfg.keystrokesEnabled = v);
        y += btnH + gap;

        addToggle(startX1, y, colW, btnH, "Armor HUD", cfg.armorHudEnabled, v -> cfg.armorHudEnabled = v);
        addToggle(startX2, y, colW, btnH, "CPS Counter", cfg.cpsCounterEnabled, v -> cfg.cpsCounterEnabled = v);
        y += btnH + gap + 8;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Save & Close"), btn -> {
            cfg.save();
            this.close();
        }).dimensions(this.width / 2 - 70, y, 140, 22).build());
    }

    private interface BoolSetter {
        void set(boolean val);
    }

    private void addToggle(int x, int y, int w, int h, String label, boolean initial, BoolSetter setter) {
        final boolean[] state = {initial};
        this.addDrawableChild(ButtonWidget.builder(formatLabel(label, state[0]), btn -> {
            state[0] = !state[0];
            setter.set(state[0]);
            btn.setMessage(formatLabel(label, state[0]));
            CrimsonGoldClient.CONFIG.save();
        }).dimensions(x, y, w, h).build());
    }

    private Text formatLabel(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "§aON" : "§cOFF"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int panelW = 340;
        int panelH = 215;
        int px = this.width / 2 - panelW / 2;
        int py = this.height / 2 - 110;

        // Dark-glass CrimsonGold panel
        context.fill(px, py, px + panelW, py + panelH, 0xD80B0A10);
        context.drawBorder(px, py, panelW, panelH, 0xFFFFD466);
        context.drawBorder(px + 1, py + 1, panelW - 2, panelH - 2, 0xFFC41E44);

        context.drawCenteredTextWithShadow(this.textRenderer, "§6§lCRIMSON GOLD §cCLIENT §7[1.21.11]", this.width / 2, py + 10, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
