package com.crimsongold.hud;

import com.crimsongold.CrimsonGoldClient;
import com.crimsongold.config.ClientConfig;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;

public class CrimsonHudRenderer implements HudRenderCallback {
    private float prevYaw = 0f;
    private float prevPitch = 0f;

    @Override
    public void onHudRender(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        ClientConfig cfg = CrimsonGoldClient.CONFIG;

        // Subtle Motion Blur velocity vignette when turning fast
        if (cfg.motionBlurEnabled) {
            float yawDiff = Math.abs(mc.player.getYaw() - prevYaw);
            float pitchDiff = Math.abs(mc.player.getPitch() - prevPitch);
            float speed = Math.min(1.0f, (yawDiff + pitchDiff) / 28.0f);
            if (speed > 0.04f) {
                int alpha = (int) (speed * cfg.motionBlurStrength * 110);
                int col = (alpha << 24) | 0x180810;
                ctx.fill(0, 0, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), col);
            }
            prevYaw = mc.player.getYaw();
            prevPitch = mc.player.getPitch();
        }

        if (!cfg.hudEnabled) return;

        // Top-Left CrimsonGold Pill: FPS + Coords + Sprint
        String fpsText = "§6FPS §f" + mc.getCurrentFps();
        String coords = String.format("§6XYZ §f%d %d %d",
                (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ());
        String cpsText = cfg.cpsCounterEnabled
                ? "  §cCPS §f" + CrimsonGoldClient.getLeftCps() + " | " + CrimsonGoldClient.getRightCps()
                : "";
        String line = fpsText + "  §8|  " + coords + cpsText;

        int boxW = mc.textRenderer.getWidth(line) + 12;
        ctx.fill(6, 6, 6 + boxW, 22, 0xB80B0A10);
        ctx.drawBorder(6, 6, boxW, 16, 0xFFC41E44);
        ctx.drawTextWithShadow(mc.textRenderer, line, 12, 10, 0xFFFFFF);

        // Keystrokes (Top-Left below info bar)
        if (cfg.keystrokesEnabled) {
            int kx = 6;
            int ky = 28;
            drawKey(ctx, mc, kx + 22, ky, 20, 18, "W", mc.options.forwardKey.isPressed());
            drawKey(ctx, mc, kx, ky + 20, 20, 18, "A", mc.options.leftKey.isPressed());
            drawKey(ctx, mc, kx + 22, ky + 20, 20, 18, "S", mc.options.backKey.isPressed());
            drawKey(ctx, mc, kx + 44, ky + 20, 20, 18, "D", mc.options.rightKey.isPressed());
            drawKey(ctx, mc, kx, ky + 40, 31, 16, "LMB", mc.options.attackKey.isPressed());
            drawKey(ctx, mc, kx + 33, ky + 40, 31, 16, "RMB", mc.options.useKey.isPressed());
        }

        // Armor HUD (Bottom-Right)
        if (cfg.armorHudEnabled) {
            int sw = mc.getWindow().getScaledWidth();
            int sh = mc.getWindow().getScaledHeight();
            int ax = sw - 24;
            int ay = sh - 22;
            for (ItemStack stack : mc.player.getArmorItems()) {
                if (!stack.isEmpty()) {
                    ctx.drawItem(stack, ax, ay);
                    ctx.drawStackOverlay(mc.textRenderer, stack, ax, ay);
                }
                ay -= 18;
            }
        }
    }

    private void drawKey(DrawContext ctx, MinecraftClient mc, int x, int y, int w, int h, String label, boolean pressed) {
        int bg = pressed ? 0xCCFFD466 : 0xB00B0A10;
        int border = pressed ? 0xFFFFFFFF : 0xFFC41E44;
        int txtCol = pressed ? 0xFF100810 : 0xFFFFFFFF;
        ctx.fill(x, y, x + w, y + h, bg);
        ctx.drawBorder(x, y, w, h, border);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, label, x + (w - tw) / 2, y + (h - 8) / 2, txtCol, false);
    }
}
